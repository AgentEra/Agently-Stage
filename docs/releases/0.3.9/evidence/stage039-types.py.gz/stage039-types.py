from agently_stage import Stage, Tunnel, StageStream
channel: Tunnel[int] = Tunnel(wake_mode="grouped")
channel.put(1)
channel.close()
values: list[int] = channel.get()
reveal_type(channel)
reveal_type(values)
