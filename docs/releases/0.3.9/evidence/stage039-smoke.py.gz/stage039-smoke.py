from importlib.metadata import version
from pathlib import Path
import agently_stage
assert version("agently-stage") == "0.3.9"
assert "/tmp/stage039" in agently_stage.__file__
assert Path(agently_stage.__file__).with_name("py.typed").is_file()
from agently_stage import Tunnel

channel = Tunnel()  # 默认 individual，0.3.8 调用可继续使用
channel.put(1)
channel.close()
assert list(channel) == [1]

# 0.3.9 新增：同一 loop 上等待的读者较多时，显式评估该选项
channel = Tunnel(wake_mode="grouped")

print(version("agently-stage"), agently_stage.__file__, "smoke passed")
