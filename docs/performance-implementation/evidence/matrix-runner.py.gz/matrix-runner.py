import os, subprocess, pathlib, sys, json
root=pathlib.Path('/Users/moxin/dev/public/Agently-Stage')
env=dict(os.environ, PYTHONPATH=str(root))
versions={
'310':'/opt/miniconda3/envs/3.10/bin/python',
'311':'/opt/miniconda3/envs/3.11/bin/python',
'312':'/tmp/stage-matrix-312/bin/python',
'313':'/tmp/stage-matrix-313/bin/python',
'314':'/Users/moxin/dev/.worktrees/Agently-long-task-artifact-delivery/spec/experiments/release-4.1.4.10/python314-env/bin/python'}
results=[]
for version, python in versions.items():
    args=[python,'-m','pytest','-q','tests','--ignore=tests/test_api/test_Stage_benchmark.py']
    with (root/f'docs/performance-implementation/evidence/stage-{version}.txt').open('w') as f:
        f.write(subprocess.check_output([python,'-V'],text=True))
        f.write('COMMAND: '+repr(args)+'\n'); f.flush()
        p=subprocess.run(args,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=150)
    results.append({'version':version,'returncode':p.returncode,'command':args})
    print(version,p.returncode,flush=True)
(root/'docs/performance-implementation/evidence/matrix.json').write_text(json.dumps(results,indent=2))
